export default function Projects() {
    return (
      <main style={{ padding: "1rem 0" }}>
        <h2>Projects</h2>
      </main>
    );
  }