export default function Dashboard() {
    return (
      <div className="dashboard-container">
        Hello World!
      </div>
    );
  }